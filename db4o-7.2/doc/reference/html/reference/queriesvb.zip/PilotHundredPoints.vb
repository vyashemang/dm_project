Imports com.db4o.query

Namespace com.db4odoc.f1.queries
    Public Class PilotHundredPoints
        Inherits Predicate
        Public Function Match(ByVal pilot As Pilot) As Boolean
            If pilot.Points = 100 Then
                Return True
            Else
                Return False
        End Function
    End Class
End Namespace