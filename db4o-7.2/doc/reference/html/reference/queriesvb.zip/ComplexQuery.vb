' Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com 
Imports com.db4o.query

Namespace com.db4odoc.f1.queries
    Public Class ComplexQuery
        Inherits Predicate
        Public Function Match(ByVal pilot As Pilot) As Boolean
            Return pilot.Points > 99 AndAlso pilot.Points < 199 OrElse pilot.Name = "Rubens Barrichello"
        End Function

    End Class
End Namespace
