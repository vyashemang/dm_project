' Copyright (C) 2004 - 2007 db4objects Inc. http:'www.db4o.com 
Imports System

Imports System.Runtime.Remoting
Imports System.Runtime.Remoting.Channels
Imports System.Runtime.Remoting.Channels.Http
Imports System.Runtime.Remoting.Channels.Tcp

Imports Interfaces


' Server class. Starts Remoting server services
Namespace Server
    Class Program
        Shared Sub Main(ByVal args As String())
            ' Using an HttpChannel
            Dim channel As HttpChannel = New HttpChannel(65101)
            ChannelServices.RegisterChannel(channel, False)

            ' Register test interface
            Dim iTest As Type = GetType(Test)
            RemotingConfiguration.RegisterWellKnownServiceType(iTest, "TestEndPoint", WellKnownObjectMode.Singleton)

            Console.WriteLine("Test Service is ready.")

            ' Keep the server running until the user presses
            ' the Enter key.
            '
            Console.WriteLine("Services are running. Press Enter to end...")
            Console.ReadLine()
        End Sub

        ' end Main
    End Class
End Namespace


