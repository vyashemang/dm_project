' Copyright (C) 2004 - 2007 db4objects Inc. http:'www.db4o.com
Imports System

' Test interface is used to create remoting objects.

Namespace Interfaces
    Public Interface ITest
        ' get object data
        Function GetData() As String

    ' set object data
        Sub ChangeData(ByVal data As String)

        ' retrieve object from the database and return its data
        Function RetrieveData() As String

        ' store object to the database
        Sub StoreData()
    End Interface
End Namespace
