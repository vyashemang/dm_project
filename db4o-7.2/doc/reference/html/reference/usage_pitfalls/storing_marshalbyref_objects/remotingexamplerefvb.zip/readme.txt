The project runs on db4o-6.2 for .NET2.
You will need to download db4o library separately and update a reference to it
from the Server project.
Once built, start the Server.exe first and run the RemotingExample.exe (can be
run in debugger).