/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System; 

/*
 * Test interface is used to create remoting objects.
 */
namespace Interfaces
{
    public interface ITest
    {
        // get object data
        string GetData();

        // set object data
        void ChangeData(string data);

        // retrieve object from the database and return its data
        string RetrieveData();

        // store object to the database
        void StoreData();
    }
}
