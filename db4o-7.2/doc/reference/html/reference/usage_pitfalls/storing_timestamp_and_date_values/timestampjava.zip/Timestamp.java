/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.timestamp;

import java.util.Date;

public class Timestamp extends Date{
	
	public Timestamp(long ms) {
		super(ms);

	}

	public String toString() {
		return super.toString();

	}
}
