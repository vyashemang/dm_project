using System;
using com.db4o;
using com.db4o.inside.query;

namespace com.db4odoc.f1.nq
{
	public class NQExample
	{
		public void SetOptimization(ObjectContainer container)
		{
			NativeQueryHandler handler = ((YapStream)container).GetNativeQueryHandler();
			handler.QueryExecution += OnQueryExecution;
			handler.QueryOptimizationFailure += OnQueryOptimizationFailure;
		}
		// end SetOptimization
	}
}
