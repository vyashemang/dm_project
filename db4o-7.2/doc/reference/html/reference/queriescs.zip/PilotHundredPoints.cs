using com.db4o.query;

namespace com.db4odoc.f1.queries
{
	public class PilotHundredPoints : Predicate 
	{
		public bool Match(Pilot pilot) 
		{
			return pilot.Points == 100;
		}
	}
}
