/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */
using com.db4o.query;

namespace com.db4odoc.f1.queries
{
	public class ComplexQuery : Predicate
	{
		public bool Match(Pilot pilot)
		{
			return pilot.Points > 99
				&& pilot.Points < 199
				|| pilot.Name=="Rubens Barrichello";
		}
	}
}
