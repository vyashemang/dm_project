/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */

package com.db4odoc.noclasses.client;


public class RecordBook {
	private String[][] notes;
	private int recordCounter;
	
	
	public RecordBook(){
		notes = new String[20][3];
		recordCounter = 0;
	}
	
	public void addRecord(String period, String pilotName, String note){
		String[] tempArray = {period, pilotName, note}; 
		notes[recordCounter] = tempArray;
		recordCounter ++;
	}
	
	public String toString(){
		String temp;
		temp = "Record book: \n";
		for (int i=0; i<recordCounter;i++ ){
			temp = temp + notes[i][0] + "/" + notes[i][1] + "/" + notes[i][2] + "\n";
		}
		return temp;
	}
}
