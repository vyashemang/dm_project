' Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com 
Namespace Db4objects.Db4odoc.Remote
    Public Class UpdateServer

    End Class
End Namespace

