/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */
import java.util.List;

import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;

public class primitiveExample {

	public final static String YAPFILENAME="formula1.yap";
	
	public static void main(String[] args) {
		ObjectContainer db = Db4o.openFile(YAPFILENAME);
		try {
			primitiveQuery(db);
		} finally {
			db.close();
		}
	}
	
	public static void primitiveQuery(ObjectContainer db){
		List pilots = db.query(new Predicate() {
		    public boolean match(Pilot pilot) {
		        return pilot.getPoints() == 100;
		    }
		});
	}

	public static void primitiveQuery1(ObjectContainer db){
		List pilots = db.query(new PilotHundredPoints());
	}

}
