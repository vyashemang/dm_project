/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */
import com.db4o.query.Predicate;

public class PilotHundredPoints extends Predicate {
    public boolean match(Pilot pilot) {
        return pilot.getPoints() == 100;
    }
}