/* Copyright (C) 2004 - 2007 db4objects Inc. http://www.db4o.com */
using System;
using System.Collections;

namespace Db4objects.Db4odoc.Soda
{
	public class Team
	{
		private ArrayList _pilots;
		private string _name;

		public Team(string name, ArrayList pilots)
		{
            _name = name;
            _pilots = pilots;
		}

        public override string ToString()
        {
            return _name + ":" + _pilots;
        }
	}
}
