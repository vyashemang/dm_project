package com.db4odoc.qbe;

public class Pilot1Derived extends Pilot1 {

	public Pilot1Derived(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
}
