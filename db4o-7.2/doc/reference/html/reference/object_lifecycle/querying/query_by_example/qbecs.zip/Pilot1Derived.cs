/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */

namespace Db4objects.Db4odoc.QBE
{
    class Pilot1Derived: Pilot1
    {
        public Pilot1Derived(string name, int points)
            : base(name, points)
        {
            
        }
    }
}
