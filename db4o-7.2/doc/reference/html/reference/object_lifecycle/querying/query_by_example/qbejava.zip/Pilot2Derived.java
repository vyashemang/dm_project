package com.db4odoc.qbe;

public class Pilot2Derived extends Pilot2 {

	public Pilot2Derived(String name) {
		super(name);
	}

}
