using System;
using System.Collections.Generic;
using System.Text;

namespace CSTest
{
    class Pilot
    {
        private int _points;
        private string _name;

        public int Points
        {
            get
            {
                return _points;
            }
            set
            {
                _points = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
    }
}
