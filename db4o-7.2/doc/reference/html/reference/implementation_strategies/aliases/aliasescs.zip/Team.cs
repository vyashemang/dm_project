using System;
using System.Collections;

namespace Db4objects.Db4odoc.Aliases
{
    public class Team
    {
        private String name;
        private ArrayList members;

        public Team(String name, ArrayList members)
        {
            this.name = name;
            this.members = members;
        }

        public ArrayList Members
        {
            get
            {
                return members;
            }
            set
            {
                members = value;
            }
        }

        public override string ToString()
        {
            string membersString = "";
            for (int i = 0; i < members.Count; i++) {
                membersString += membersString + "|" + members[i];
            }
            return name + ":" + membersString;
        }

    }
}
