' Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com 

Namespace Db4objects.Db4odoc.Binding
    Public Class Customer
        Dim _name As String
        Dim _phoneNumber As String

        Public Sub New(ByVal name As String, ByVal phoneNumber As String)
            _name = name
            _phoneNumber = phoneNumber
        End Sub

        Public Property Name() As String
            Get
                Return _name
            End Get
            Set(ByVal Value As String)
                _name = Value
            End Set
        End Property

        Public Property PhoneNumber() As String
            Get
                Return _phoneNumber
            End Get
            Set(ByVal Value As String)
                _phoneNumber = Value
            End Set
        End Property
    End Class
End Namespace
