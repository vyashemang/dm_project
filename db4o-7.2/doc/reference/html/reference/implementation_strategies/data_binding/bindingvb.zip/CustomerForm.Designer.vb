<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustomerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me._labelName = New System.Windows.Forms.Label
        Me._labelPhone = New System.Windows.Forms.Label
        Me._cmbCustomers = New System.Windows.Forms.ComboBox
        Me._txtPhoneNumber = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        '_labelName
        '
        Me._labelName.AutoSize = True
        Me._labelName.Location = New System.Drawing.Point(12, 9)
        Me._labelName.Name = "_labelName"
        Me._labelName.Size = New System.Drawing.Size(51, 13)
        Me._labelName.TabIndex = 0
        Me._labelName.Text = "Customer"
        '
        '_labelPhone
        '
        Me._labelPhone.AutoSize = True
        Me._labelPhone.Location = New System.Drawing.Point(12, 40)
        Me._labelPhone.Name = "_labelPhone"
        Me._labelPhone.Size = New System.Drawing.Size(45, 13)
        Me._labelPhone.TabIndex = 1
        Me._labelPhone.Text = "Phone#"
        '
        '_cmbCustomers
        '
        Me._cmbCustomers.FormattingEnabled = True
        Me._cmbCustomers.Location = New System.Drawing.Point(103, 6)
        Me._cmbCustomers.Name = "_cmbCustomers"
        Me._cmbCustomers.Size = New System.Drawing.Size(177, 21)
        Me._cmbCustomers.TabIndex = 2
        '
        '_txtPhoneNumber
        '
        Me._txtPhoneNumber.Location = New System.Drawing.Point(103, 37)
        Me._txtPhoneNumber.Name = "_txtPhoneNumber"
        Me._txtPhoneNumber.Size = New System.Drawing.Size(177, 20)
        Me._txtPhoneNumber.TabIndex = 3
        '
        'CustomerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 66)
        Me.Controls.Add(Me._txtPhoneNumber)
        Me.Controls.Add(Me._cmbCustomers)
        Me.Controls.Add(Me._labelPhone)
        Me.Controls.Add(Me._labelName)
        Me.Name = "CustomerForm"
        Me.Text = "Db4o Data Binding"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents _labelName As System.Windows.Forms.Label
    Friend WithEvents _labelPhone As System.Windows.Forms.Label
    Friend WithEvents _cmbCustomers As System.Windows.Forms.ComboBox
    Friend WithEvents _txtPhoneNumber As System.Windows.Forms.TextBox
End Class
