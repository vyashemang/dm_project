/* Copyright (C) 2004 - 2006 db4objects Inc. http://www.db4o.com */
namespace Db4objects.Db4odoc.Binding
{
	/// <summary>
	/// A simple business class.
	/// </summary>
	public class Customer
	{
		string _name;
		string _phoneNumber;

		public Customer(string name, string phoneNumber)
		{
			_name = name;
			_phoneNumber = phoneNumber;
		}

		public string Name
		{
			get
			{
				return _name;
			}

			set
			{
				_name = value;
			}
		}

		public string PhoneNumber
		{
			get
			{
				return _phoneNumber;
			}

			set
			{
				_phoneNumber = value;
			}
		}
	}
}
