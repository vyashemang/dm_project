Imports Db4objects.Db4odoc.ReportsExample.Modules

Public Class Form1

    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Db4oManager.CloseDb()
    End Sub
    ' end Form1_FormClosed

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Add data to the database
        Db4oManager.FillUpDB()
        ' Bind the Pilot list to the report DataSource
        Me.PilotBindingSource.DataSource = Db4oManager.GetAllPilots()
        Me.ReportViewer1.RefreshReport()
        Me.ReportViewer1.RefreshReport()
    End Sub
    ' end Form1_Load

End Class

