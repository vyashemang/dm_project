using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Db4objects.Db4odoc.ReportsExample.Modules;
using Db4objects.Db4odoc.ReportsExample.Persistent;

namespace Db4objects.Db4odoc.ReportsExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // end Form1

        private void Form1_Load(object sender, EventArgs e)
        {
            // Add data to the database
            Db4oManager.FillUpDB();
            // Bind the Pilot list to the report DataSource
            this.PilotBindingSource.DataSource = Db4oManager.GetAllPilots();
            this.reportViewer1.RefreshReport();
        }
        // end Form1_Load

        
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Db4oManager.CloseDb();
        }
        // end Form1_FormClosed
    }
}