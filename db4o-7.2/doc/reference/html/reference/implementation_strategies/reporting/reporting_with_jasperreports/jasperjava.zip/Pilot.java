

public class Pilot {
	private String name;

	private int points;

	public Pilot(String name, int points) {
		this.name = name;
		this.points = points;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public int getPoints() {
		return points;
	}

	public boolean equals(Object obj) {
		if (obj instanceof Pilot) {
			return (((Pilot) obj).getName().equals(name) && 
					((Pilot) obj).getPoints() == points);
		}
		return false;
	}

	public String toString() {
		return name + "/" + points;
	}

	public int hashCode() {
		return name.hashCode() + points;
	}
}
