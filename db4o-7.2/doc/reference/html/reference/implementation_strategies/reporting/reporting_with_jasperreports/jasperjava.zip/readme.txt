This project needs some external libraries to work.
Create /lib folder inside the project folder and add the following 
jars:
commons-beanutils.jar
commons-collections.jar
commons-digester-1.7.jar
commons-logging-1.1.jar
itext-1.3.jar
jasperreports-1.3.2.jar
db4o-java5-6.2.jar

Check the java build path to make sure that all of these libraries
are referenced.