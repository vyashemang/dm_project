Namespace Db4objects.Db4odoc.NQCollection

    Public Interface Person
    End Interface

End Namespace