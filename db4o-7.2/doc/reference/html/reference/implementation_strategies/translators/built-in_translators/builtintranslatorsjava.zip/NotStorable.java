/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.builtintranslators;

public class NotStorable {
	String _name;

	public NotStorable(String name) {
		_name = name;
	}

	public String toString() {
		return _name == null ? "null" : _name;
	}
}
