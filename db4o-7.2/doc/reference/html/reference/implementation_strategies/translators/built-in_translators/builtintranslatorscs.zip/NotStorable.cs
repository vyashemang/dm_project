/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */
namespace Db4objects.Db4odoc.BuiltInTranslators
{
    public class NotStorable
    {
        string _name;
        public NotStorable(string name)
        {
            _name = name;
        }

        public override string ToString()
        {
            return _name == null ? "null" : _name;
        }
    }
}
