/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.builtintranslators;

import java.io.Serializable;

public class Pilot  implements Serializable {
	public String _name;

	public int _points;

	public Pilot() {
	}

	public Pilot(String name, int points) {
		_name = name;
		_points = points;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	public int getPoints() {
		return _points;
	}

	public String toString() {
		return _name + "/" + _points;
	}

}
