/* Copyright (C) 2007 db4objects Inc. http://www.db4o.com */

package com.db4odoc.builtintranslators;


public class Item {
	String _name;
	NotStorable _ns;
	
	public Item(String name, NotStorable ns) {
		_name = name;
		_ns = ns;
	}
	
	public String toString() {
		return _name + "/" + (_ns == null ? "null" : _ns);
	}
}
